#import <Foundation/Foundation.h>

@interface com_myrestaurant_app_payment_BraintreeNativeImpl : NSObject {
}

-(void)showChargeUI:(NSString*)param;
-(BOOL)isSupported;
@end
