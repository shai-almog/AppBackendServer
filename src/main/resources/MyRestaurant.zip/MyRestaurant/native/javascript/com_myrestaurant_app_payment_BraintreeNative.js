(function(exports){

var o = {};

    o.showChargeUI__java_lang_String = function(param1, callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.isSupported_ = function(callback) {
        callback.complete(false);
    };

exports.com_myrestaurant_app_payment_BraintreeNative= o;

})(cn1_get_native_interfaces());
