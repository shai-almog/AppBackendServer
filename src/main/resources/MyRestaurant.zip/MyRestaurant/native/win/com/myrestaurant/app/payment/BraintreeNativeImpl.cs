namespace com.myrestaurant.app.payment{


public class BraintreeNativeImpl : IBraintreeNativeImpl {
    public void showChargeUI(String param) {
    }

    public bool isSupported() {
        return false;
    }

}
}
