package com.myrestaurant.app.payment;

public class BraintreeNativeImpl {
    public void showChargeUI(String param) {
    }

    public boolean isSupported() {
        return false;
    }

}
