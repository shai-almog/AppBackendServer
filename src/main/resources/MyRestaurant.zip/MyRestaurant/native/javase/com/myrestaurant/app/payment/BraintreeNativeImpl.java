package com.myrestaurant.app.payment;

public class BraintreeNativeImpl implements com.myrestaurant.app.payment.BraintreeNative{
    public void showChargeUI(String param) {
    }

    public boolean isSupported() {
        return false;
    }

}
